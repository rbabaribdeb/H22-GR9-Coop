from django.apps import AppConfig


class RenaissanceCoopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RENAISSANCE_COOP'
